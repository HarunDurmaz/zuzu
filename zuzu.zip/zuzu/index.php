<!DOCTYPE html>
<html>

<head>
    <title>Order Form Example</title>
    <link href="sushi.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    // require "index.php";
    require_once('database.php');
    require('process.php');
    // (A) PROCESS ORDER FORM
    if (isset($_POST["name"])) {

        echo $result == ""
            ? "<div class='notify'>Bedankt! uw bestelling komt eraan!</div>"
            : "<div class='notify'>$result</div>";
    }
    ?>

    <img style="width: 100%" src="img/Header.jpg" alt="">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">Features</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="#">Pricing</a>
                </li>
            </ul>
            </div>
        </div>
        </nav>

        

    <h1><a href="index.php">Lekkere Sushi</a></h1>

    <form id="orderform" method="post" target="_self">
        <label for="fname" class="form-label">Voornaam:</label> <br>
        <input class="form-label" type="text" name="fname" required value="" /> <br>

        <label class="form-label" for="lname">Achternaam:</label> <br>
        <input class="form-label" type="text" name="lname" required value="" /> <br>

        <label class="form-label" for="address">Address:</label> <br>
        <input class="form-label" type="text" name="address" required value="" /> <br>

        <label class="form-label" for="zipcode">Postcode:</label> <br>
        <input class="form-label" type="text" name="zipcode" required value="" /> <br>
        
        <label class="form-label" for="city">Stad:</label> <br>
        <input class="form-label" type="text" name="city" required value="" /> <br>

        <br>


        
            <select name="sushi_id">
                <option selected disabled value="">Kies een sushi!</option>
                <?php
                global $pdo;
                $sql = $pdo->prepare("SELECT * FROM sushi");
                $sql->execute();
                $result = $sql->fetchAll(PDO::FETCH_ASSOC);

                foreach ($result as $data) {
                    echo "
                    <option selected enabled id='$data[id]' value='$data[name]'>" . $data['name'] .  ". Vooraad: " . $data['amount'] . "</option>
                ";
                }
                ?>
            </select> <br>
            <p class=hoeveelheid>Aantal</p>
            <input type="number" name="amount" placeholder="0"> <br>

            <input type="submit" name="submit">
    </form>


        <?php
        global $pdo;
        if (isset($_POST['submit'])) {
            if ($_POST['amount'] != 0 && !empty($_POST['amount'])) {
                $amount = $_POST['amount'];
                $sushi = $_POST['sushi_id'];


                $sql = $pdo->prepare("SELECT * FROM sushi");
                $sql->execute();
                $result = $sql->fetchAll(PDO::FETCH_ASSOC);

                foreach ($result as $data) {
                    if ($data['name'] == $sushi) {
                        $name = $data['name'];
                        $price = $data['price'];
                        $id = $data['id'];
                        $sa = $amount;
                        if ($sa > 1) {
                            $stp = $data['price'] * $sa;
                        } else {
                            $stp = $price;
                        }
                    }
                }

                $new_amount = $data['amount'] - $amount;

                if ($amount > $data['amount']) {
                    echo 'we hebben jammer genoeg de hoeveelheid shusi niet in onze opslag.';
                } else {
                    $sql2 = $pdo->prepare("UPDATE sushi SET amount = $new_amount WHERE id = $id");
                    $sql2->execute();

                    echo "<table>

                    <tr>
                        <th>Sushi</th>
                        <th>Prijs</th>
                        <th>Hoeveelheid</th>
                        <th>Totaal Prijs</th>
                    </tr>
                    <tr>
                        <td>" . $name . "</td>
                        <td>" . $price . "</td>
                        <td>" . $sa . "</td>
                        <td>" . $stp . "</td>
                    </tr>
                </table>";
                }

        
            } else {
                echo '<script>alert("Fill in all fields.");</script>';
            }
        }
        ?>

        



</body>

</html>
